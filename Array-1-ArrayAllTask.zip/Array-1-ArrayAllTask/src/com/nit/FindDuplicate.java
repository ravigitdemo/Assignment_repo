package com.nit;

public class FindDuplicate {
	public static void main(String[] args) {
		int arr[]= {1,2,6,2,4,3,3};
		for(int i=0;i<arr.length-1;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]==arr[j]) {
					System.out.println("The duplicate element in array is"+arr[j]);
				}
			}
		}
	}
	
}
