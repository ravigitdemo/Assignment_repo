package com.nit;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class UniqueElementSum {
	public static void main(String[] args) {
		int arr[]= {1,2,3,2};
		removeDuplicate(arr);
	}
	public static void removeDuplicate(int []arr) {
		int sum=0;
		List<Integer> list = new ArrayList<>();
		for(int i:arr) {
			list.add(i);
		}
		Set<Integer>  set = new LinkedHashSet<>(list);
		for(int i:set) {
			sum=sum+i;
			System.out.println("after removing duplicate values:"+i);
		}
		System.out.println("Sum of unique value is:"+sum);
	}

}
