package com.nit;

public class SecondSmallestSum {
	public static void main(String[] args) {
		int arr[]= {1,3,2,4,6};
		int temp,a,b,c;
		for(int i=0;i<arr.length-1;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		a=arr[1];
		b=arr[0];
		c=a+b;
		System.out.println("Second Smallest Element is::"+c);
	}

}
