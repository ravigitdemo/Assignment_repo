package com.nit;

public class MinMaxValue {
	public static void main(String[] args) {
		int arr[]= {2,3,1,5,4};
		int big=arr[0];
		int small=arr[0];
		
		for(int i=0;i<arr.length-1;i++) {
			if(big<arr[i])
				big=arr[i];
		}
		for(int i=0;i<arr.length-1;i++) {
			if(small>arr[i])
				small=arr[i];
		}
		System.out.println("Biggest Number:"+big);
		System.out.println("Smallest Number:"+small);
	}

}
