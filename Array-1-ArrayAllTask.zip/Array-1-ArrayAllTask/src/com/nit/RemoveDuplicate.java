package com.nit;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicate {
	public static void main(String[] args) {
		int arr[]= {2,3,4,1,2,3,5};
		removeDuplicateElement(arr);
	}
	public static void removeDuplicateElement(int []arr) {
		List<Integer> list = new ArrayList<>();
		for(int i:arr) {
			list.add(i);
		}
		
		Set<Integer> set = new LinkedHashSet<>(list);
		for(int val:set) {
			System.out.println("New element is:"+val);
		}
		
	}

}
