package com.codingtips.beans;

import java.util.List;

import com.codingtips.model.Product;

public interface RecordFilter {
	
	public List<Product> filterRecords(List<Product> productList);

}
