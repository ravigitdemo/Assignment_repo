package com.codingtips.beans;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.codingtips.model.Product;

@Component
public class CsvReader {
	@Autowired
	private RecordFilter rFilter;
	
	public List<Product> readProductRecord() throws IOException{
		List<Product> list = new ArrayList<>();
		File f = new File("product.txt");
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		String readLine=br.readLine();
		
		while(readLine!=null) {
			String str[]=readLine.split(",");
			String pId=str[0];
			String pName=str[1];
			String pPrice=str[2];
			
			Product p = new Product();
			p.setpId(Integer.parseInt(pId));
			p.setpName(pName);
			p.setpPrice(Double.parseDouble(pPrice));
			list.add(p);
			readLine=br.readLine();
		}
		return rFilter.filterRecords(list);
		
	}

}
