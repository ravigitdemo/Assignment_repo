package com.codingtips.beans;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.codingtips.model.Product;

@Component
public class RecordFilterImpl implements RecordFilter{

	@Override
	public List<Product> filterRecords(List<Product> productList) {
		
		return productList.stream()
				.filter(p ->p.getpPrice()>=5000)
				.collect(Collectors.toList());
	}

}
