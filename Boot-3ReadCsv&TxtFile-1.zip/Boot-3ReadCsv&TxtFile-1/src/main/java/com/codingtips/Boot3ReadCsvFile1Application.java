package com.codingtips;

import java.io.IOException;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.codingtips.beans.CsvReader;
import com.codingtips.model.Product;

@SpringBootApplication
public class Boot3ReadCsvFile1Application {

	public static void main(String[] args) throws IOException {
		//create IOC
		ConfigurableApplicationContext ctx=null;
		//reder class object
		CsvReader csv=null;
		ctx=SpringApplication.run(Boot3ReadCsvFile1Application.class, args);
		csv=ctx.getBean(CsvReader.class);
		List<Product> productList=csv.readProductRecord();
		productList.forEach(System.out::println);
		
	}

}
